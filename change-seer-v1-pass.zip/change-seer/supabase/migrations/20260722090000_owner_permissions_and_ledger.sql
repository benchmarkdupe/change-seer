-- =====================================================================
-- Owner/permission hierarchy, richer cash-flow categories, audit log,
-- feature flags, and project progress log.
--
-- This migration is intentionally defensive: the owner role and the
-- reserved "benchmark" identity cannot be granted, claimed, or revoked
-- through the normal authenticated-user path. Every check below runs
-- inside the database (RLS + triggers), not the frontend, per the
-- product's security requirements.
-- =====================================================================

-- === APP_ROLE: add 'owner', keep everything else -----------------------
-- Postgres won't let a brand-new enum value be used in the same
-- transaction it's added in, so we swap the type instead of ALTER ...
-- ADD VALUE. This keeps the whole migration transactional and safe to
-- re-run in a single `supabase db push`.
CREATE TYPE public.app_role_new AS ENUM (
  'user', 'early_access', 'builder', 'moderator', 'admin', 'developer', 'owner'
);

ALTER TABLE public.user_roles
  ALTER COLUMN role TYPE public.app_role_new
  USING role::text::public.app_role_new;

DROP FUNCTION IF EXISTS public.has_role(UUID, public.app_role);
DROP TYPE public.app_role;
ALTER TYPE public.app_role_new RENAME TO app_role;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) TO authenticated, service_role;

-- Rank-based permission check so callers don't need to know every role
-- name — "does this user have at least MODERATOR" grows automatically
-- if a role is inserted between two existing ranks later.
CREATE OR REPLACE FUNCTION public.role_rank(_role public.app_role)
RETURNS INT LANGUAGE SQL IMMUTABLE AS $$
  SELECT CASE _role
    WHEN 'owner' THEN 100
    WHEN 'admin' THEN 80
    WHEN 'moderator' THEN 60
    WHEN 'developer' THEN 50
    WHEN 'builder' THEN 20
    WHEN 'early_access' THEN 10
    WHEN 'user' THEN 0
  END;
$$;

CREATE OR REPLACE FUNCTION public.has_at_least(_user_id UUID, _min public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND public.role_rank(role) >= public.role_rank(_min)
  );
$$;
REVOKE EXECUTE ON FUNCTION public.has_at_least(UUID, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_at_least(UUID, public.app_role) TO authenticated, service_role;

-- === OWNER PROTECTION ---------------------------------------------------
-- Only one 'owner' row can ever exist, and only service_role (server-side,
-- never the browser) can insert, update, or delete it.
CREATE UNIQUE INDEX idx_single_owner ON public.user_roles (role) WHERE role = 'owner';

CREATE OR REPLACE FUNCTION public.protect_owner_role()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF (TG_OP = 'DELETE' AND OLD.role = 'owner') OR
     (TG_OP IN ('INSERT', 'UPDATE') AND NEW.role = 'owner') THEN
    IF auth.role() IS DISTINCT FROM 'service_role' THEN
      RAISE EXCEPTION 'The owner role can only be granted or revoked by a server-side operation.';
    END IF;
  END IF;
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_protect_owner_role
  BEFORE INSERT OR UPDATE OR DELETE ON public.user_roles
  FOR EACH ROW EXECUTE FUNCTION public.protect_owner_role();

-- Reserve the "benchmark" identity so no other account can ever claim it,
-- change into it, or squat a lookalike via case variation. Setting this
-- username is a service-role-only operation (done once, out of band).
CREATE UNIQUE INDEX idx_profiles_username_lower ON public.profiles (lower(username));

CREATE OR REPLACE FUNCTION public.protect_reserved_username()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.username IS NOT NULL AND lower(NEW.username) = 'benchmark' THEN
    IF auth.role() IS DISTINCT FROM 'service_role' THEN
      RAISE EXCEPTION 'This username is reserved.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_protect_reserved_username
  BEFORE INSERT OR UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.protect_reserved_username();

-- Admins/moderators may edit metadata on other profiles (Part 6), but
-- can never touch role assignment through this table — that only ever
-- happens through user_roles, which the trigger above already guards.
CREATE POLICY "Admins manage profiles"
  ON public.profiles FOR UPDATE
  USING (public.has_at_least(auth.uid(), 'admin'))
  WITH CHECK (public.has_at_least(auth.uid(), 'admin'));

-- Admins may grant/revoke non-owner roles; the owner row stays protected
-- by the trigger regardless of who runs this policy.
CREATE POLICY "Admins manage non-owner roles"
  ON public.user_roles FOR ALL
  USING (public.has_at_least(auth.uid(), 'admin') AND role <> 'owner')
  WITH CHECK (public.has_at_least(auth.uid(), 'admin') AND role <> 'owner');

-- === AUDIT LOG -----------------------------------------------------------
CREATE TABLE public.audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_table TEXT,
  target_id TEXT,
  detail JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_log_created ON public.audit_log (created_at DESC);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
GRANT ALL ON public.audit_log TO service_role;
CREATE POLICY "Owner and admin read audit log"
  ON public.audit_log FOR SELECT
  USING (public.has_at_least(auth.uid(), 'admin'));

-- === FEATURE FLAGS ---------------------------------------------------
CREATE TABLE public.feature_flags (
  key TEXT PRIMARY KEY,
  enabled BOOLEAN NOT NULL DEFAULT false,
  description TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL
);
ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.feature_flags TO anon, authenticated;
GRANT ALL ON public.feature_flags TO service_role;
CREATE POLICY "Feature flags are public read" ON public.feature_flags FOR SELECT USING (true);

-- === RICHER TRANSACTION KINDS -----------------------------------------
-- Manual cash-flow tracking needs to distinguish capital in (investment)
-- from revenue (income), and fees/refunds from plain expenses, so ROI
-- and profit are never conflated with money that was simply moved.
CREATE TYPE public.transaction_kind_new AS ENUM (
  'income', 'expense', 'investment', 'withdrawal', 'refund', 'fee'
);
ALTER TABLE public.transactions
  ALTER COLUMN kind TYPE public.transaction_kind_new
  USING kind::text::public.transaction_kind_new;
DROP TYPE public.transaction_kind;
ALTER TYPE public.transaction_kind_new RENAME TO transaction_kind;

ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS note TEXT;

-- === PROJECT DETAIL FIELDS + PROGRESS LOG -----------------------------
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS target TEXT;
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS time_invested_hours NUMERIC NOT NULL DEFAULT 0;

CREATE TABLE public.project_updates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_project_updates_project ON public.project_updates (project_id, created_at DESC);
ALTER TABLE public.project_updates ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, DELETE ON public.project_updates TO authenticated;
GRANT ALL ON public.project_updates TO service_role;
CREATE POLICY "Users manage updates on own projects"
  ON public.project_updates FOR ALL
  USING (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM public.projects p WHERE p.id = project_id AND p.user_id = auth.uid())
  )
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM public.projects p WHERE p.id = project_id AND p.user_id = auth.uid())
  );
CREATE POLICY "Updates on public projects are readable"
  ON public.project_updates FOR SELECT
  USING (EXISTS (SELECT 1 FROM public.projects p WHERE p.id = project_id AND p.visibility = 'public'));

-- === BADGE SEED: FIRST BUILD / FIRST SALE already exist. Add OWNER badge.
INSERT INTO public.badges (id, name, description, rarity, icon, color, max_supply)
VALUES ('owner', 'Owner', 'Platform owner.', 'mythic', 'crown', 'tier-high', 1)
ON CONFLICT (id) DO NOTHING;
