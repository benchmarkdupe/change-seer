-- =====================================================================
-- Badge integrity, provenance, lightweight product analytics, and the
-- source-candidate review pipeline (DISCOVERED -> ... -> MONITORED).
-- =====================================================================

-- === CLOSE A REAL HOLE: user_badges UPDATE policy had no WITH CHECK ---
-- "Users toggle own badge display" only restricted which ROW a user
-- could touch, not which COLUMNS — a signed-in user could run an UPDATE
-- against their own row and rewrite badge_id/issue_number to claim any
-- badge, including administrative ones. Badges must be earned or
-- granted, never self-equipped.
ALTER TABLE public.user_badges ADD COLUMN IF NOT EXISTS awarded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL;
COMMENT ON COLUMN public.user_badges.awarded_by IS 'NULL = earned automatically by a system rule/trigger. Set = granted manually by this admin/owner.';

CREATE OR REPLACE FUNCTION public.protect_badge_grant()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF auth.role() = 'service_role' THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF NEW.badge_id IS DISTINCT FROM OLD.badge_id
      OR NEW.user_id IS DISTINCT FROM OLD.user_id
      OR NEW.issue_number IS DISTINCT FROM OLD.issue_number
      OR NEW.awarded_by IS DISTINCT FROM OLD.awarded_by
      OR NEW.earned_at IS DISTINCT FROM OLD.earned_at
    THEN
      RAISE EXCEPTION 'Only the displayed flag can be changed on an existing badge.';
    END IF;
    RETURN NEW;
  END IF;
  -- INSERT: an authenticated (non-service) caller can never insert a row
  -- directly — badges are earned via triggers or granted via the admin
  -- server function, both of which run as service_role.
  RAISE EXCEPTION 'Badges cannot be self-granted.';
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_badge_grant ON public.user_badges;
CREATE TRIGGER trg_protect_badge_grant
  BEFORE INSERT OR UPDATE ON public.user_badges
  FOR EACH ROW EXECUTE FUNCTION public.protect_badge_grant();

-- === PRODUCT EVENTS -----------------------------------------------------
-- Minimal event log so we can learn what people actually do, without
-- collecting anything beyond what's needed to answer that.
CREATE TABLE public.product_events (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  event_name TEXT NOT NULL,
  subject_type TEXT,
  subject_id TEXT,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_product_events_name ON public.product_events (event_name, created_at DESC);
ALTER TABLE public.product_events ENABLE ROW LEVEL SECURITY;
GRANT INSERT ON public.product_events TO anon, authenticated;
GRANT ALL ON public.product_events TO service_role;
-- Insert-only for regular users; nobody can read someone else's events
-- through the client — analysis happens via the admin console (service role).
CREATE POLICY "Anyone can log an event as themselves"
  ON public.product_events FOR INSERT
  WITH CHECK (user_id IS NULL OR user_id = auth.uid());
CREATE POLICY "Admins read events"
  ON public.product_events FOR SELECT
  USING (public.has_at_least(auth.uid(), 'admin'));

-- === SOURCE CANDIDATE REVIEW PIPELINE -----------------------------------
-- DISCOVERED -> REVIEWED -> APPROVED -> IMPLEMENTATION_PROPOSED
--   -> IMPLEMENTED -> MONITORED (or REJECTED at any point).
-- A candidate never touches production code by itself; it's a proposal
-- an admin reviews, and "implemented" just means an engineer wired up
-- a real scout for it and linked that here.
CREATE TABLE public.source_candidates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  url TEXT,
  category TEXT NOT NULL,
  data_available TEXT,
  rationale TEXT,
  overlaps_with TEXT,
  access_method TEXT,
  reliability_notes TEXT,
  possible_signals TEXT,
  implementation_difficulty TEXT CHECK (implementation_difficulty IN ('low', 'medium', 'high')),
  status TEXT NOT NULL DEFAULT 'discovered'
    CHECK (status IN ('discovered', 'reviewed', 'approved', 'implementation_proposed', 'implemented', 'monitored', 'rejected')),
  linked_scout_key TEXT,
  proposed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.source_candidates ENABLE ROW LEVEL SECURITY;
GRANT ALL ON public.source_candidates TO service_role;
CREATE POLICY "Admins manage source candidates"
  ON public.source_candidates FOR ALL
  USING (public.has_at_least(auth.uid(), 'admin'))
  WITH CHECK (public.has_at_least(auth.uid(), 'admin'));

INSERT INTO public.badges (id, name, description, rarity, icon, color, max_supply)
VALUES
  ('verified-outcome', 'Verified Outcome', 'A project result an admin has independently verified.', 'legendary', 'badge-check', 'state-verified', NULL),
  ('contributor', 'Contributor', 'Recognized for a meaningful contribution to the community.', 'rare', 'heart-handshake', 'primary', NULL),
  ('moderator', 'Moderator', 'Community moderator.', 'epic', 'shield', 'tier-mod', NULL)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.source_candidates
  (name, category, data_available, rationale, access_method, reliability_notes, possible_signals, implementation_difficulty, status, linked_scout_key)
VALUES
  ('Hacker News (Algolia API)', 'community', 'Story titles, points, comment counts, timestamps',
   'Free, no key required, high signal-to-noise for early software/business trends among a technical audience.',
   'Public REST API (hn.algolia.com)', 'Historically stable; no auth needed', 'demand velocity, emerging topics, trend acceleration',
   'low', 'monitored', 'hacker-news'),
  ('eBay Browse/Marketplace Insights API', 'marketplace', 'Sold listing counts, price ranges, category activity',
   'Directly observable resale demand and price movement — the clearest real signal for resale/arbitrage opportunities.',
   'OAuth2 REST API, requires developer account + client credentials', 'Rate-limited; requires an eBay developer account (blocked until credentials exist)',
   'sell-through rate, price movement, demand/supply imbalance', 'medium', 'approved', NULL),
  ('BLS / Indeed job posting indices', 'labor', 'Job posting volume by category/region, salary ranges',
   'Grounds "job market" signals in actual government/labor data instead of guesses.',
   'Public CSV/API endpoints (BLS), Indeed requires partner access', 'BLS is free and stable; Indeed API access is restricted',
   'labor demand, skill requirements, geographic concentration', 'medium', 'reviewed', NULL),
  ('Google Trends (unofficial pytrends-style access)', 'trend', 'Relative search interest over time by keyword/region',
   'Useful directional trend signal, but explicitly NOT proof of profitability — must be labeled as trend-only in the UI.',
   'No official public API; would require an unofficial client or a paid provider', 'Unofficial access is fragile and can break without notice',
   'trend acceleration, seasonality, regional interest', 'high', 'discovered', NULL),
  ('Reddit API (official, OAuth)', 'community', 'Post/comment volume, upvotes, subreddit activity',
   'Recurring-problem and demand signals from communities, if pulled from the real API rather than simulated.',
   'OAuth2 REST API, requires a registered Reddit app', 'Requires app registration + user agent; rate-limited',
   'recurring problems, complaints, emerging interest', 'medium', 'discovered', NULL)
ON CONFLICT DO NOTHING;
