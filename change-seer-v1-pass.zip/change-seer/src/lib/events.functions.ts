import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Fire-and-forget event logging for signed-in actions. Kept intentionally
 * simple — no separate anonymous-tracking path, no new auth mechanism.
 * If this insert fails, the caller's own action must not fail with it.
 */
export const trackEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      eventName: z.string().min(1).max(60),
      subjectType: z.string().max(40).optional().nullable(),
      subjectId: z.string().max(200).optional().nullable(),
      meta: z.record(z.string(), z.unknown()).optional().nullable(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    try {
      await context.supabase.from("product_events").insert({
        user_id: context.userId,
        event_name: data.eventName,
        subject_type: data.subjectType ?? null,
        subject_id: data.subjectId ?? null,
        meta: (data.meta ?? null) as never,
      });
    } catch {
      // best-effort only — never surface an analytics failure to the user
    }
    return { ok: true };
  });
