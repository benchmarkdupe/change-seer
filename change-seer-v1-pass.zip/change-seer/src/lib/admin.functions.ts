import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireRole } from "@/integrations/supabase/require-role";

const MANAGEABLE_ROLES = ["user", "early_access", "builder", "moderator", "admin", "developer"] as const;

async function writeAuditLog(actorId: string, action: string, targetTable: string, targetId: string, detail?: unknown) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await supabaseAdmin.from("audit_log").insert({
    actor_id: actorId,
    action,
    target_table: targetTable,
    target_id: targetId,
    detail: (detail ?? null) as never,
  });
}

export const listUsers = createServerFn({ method: "GET" })
  .middleware([requireRole("admin")])
  .inputValidator((d) => z.object({ search: z.string().max(80).optional() }).parse(d ?? {}))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let query = supabaseAdmin
      .from("profiles")
      .select("id, username, display_name, created_at, visibility, user_roles(role), user_badges(badge_id)")
      .order("created_at", { ascending: false })
      .limit(200);
    if (data.search) {
      query = query.or(`username.ilike.%${data.search}%,display_name.ilike.%${data.search}%`);
    }
    const { data: rows, error } = await query;
    if (error) throw error;
    return rows ?? [];
  });

export const grantRole = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .inputValidator((d) =>
    z.object({ userId: z.string().uuid(), role: z.enum(MANAGEABLE_ROLES) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: data.userId, role: data.role });
    if (error && !error.message.includes("duplicate")) throw error;
    await writeAuditLog(context.userId, "grant_role", "user_roles", data.userId, { role: data.role });
    return { ok: true };
  });

export const revokeRole = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .inputValidator((d) =>
    z.object({ userId: z.string().uuid(), role: z.enum(MANAGEABLE_ROLES) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    // The owner role is filtered out of MANAGEABLE_ROLES entirely, and the
    // database trigger `trg_protect_owner_role` would reject this anyway
    // even if a caller bypassed validation — defense in depth.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", data.userId)
      .eq("role", data.role);
    if (error) throw error;
    await writeAuditLog(context.userId, "revoke_role", "user_roles", data.userId, { role: data.role });
    return { ok: true };
  });

export const listAuditLog = createServerFn({ method: "GET" })
  .middleware([requireRole("admin")])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("audit_log")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw error;
    return data ?? [];
  });

export const grantBadge = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), badgeId: z.string().min(1).max(60) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_badges")
      .insert({ user_id: data.userId, badge_id: data.badgeId, awarded_by: context.userId });
    if (error && !error.message.includes("duplicate")) throw error;
    await writeAuditLog(context.userId, "grant_badge", "user_badges", data.userId, { badgeId: data.badgeId });
    return { ok: true };
  });

export const revokeBadge = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), badgeId: z.string().min(1).max(60) }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("user_badges")
      .delete()
      .eq("user_id", data.userId)
      .eq("badge_id", data.badgeId);
    if (error) throw error;
    await writeAuditLog(context.userId, "revoke_badge", "user_badges", data.userId, { badgeId: data.badgeId });
    return { ok: true };
  });

/**
 * A single, honest snapshot of what's real in the product right now:
 * how many users, how much of what they're looking at is sample vs
 * live, and whether the one connected real source is actually healthy.
 * This is what "admin observability" means for a V1 — no separate
 * metrics platform, just direct counts against the tables that matter.
 */
export const getSystemStats = createServerFn({ method: "GET" })
  .middleware([requireRole("admin")])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [users, projects, transactions, savedOpps, sourceHealth, events24h] = await Promise.all([
      supabaseAdmin.from("profiles").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("projects").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("transactions").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("saved_opportunities").select("id", { count: "exact", head: true }),
      supabaseAdmin.from("source_health").select("*"),
      supabaseAdmin
        .from("product_events")
        .select("id", { count: "exact", head: true })
        .gte("created_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
    ]);
    return {
      totalUsers: users.count ?? 0,
      totalProjects: projects.count ?? 0,
      totalTransactions: transactions.count ?? 0,
      totalSavedOpportunities: savedOpps.count ?? 0,
      eventsLast24h: events24h.count ?? 0,
      sources: sourceHealth.data ?? [],
    };
  });

export const listSourceCandidates = createServerFn({ method: "GET" })
  .middleware([requireRole("admin")])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("source_candidates")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  });

const CANDIDATE_STATUSES = [
  "discovered", "reviewed", "approved", "implementation_proposed", "implemented", "monitored", "rejected",
] as const;

export const updateSourceCandidateStatus = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .inputValidator((d) =>
    z.object({ id: z.string().uuid(), status: z.enum(CANDIDATE_STATUSES) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("source_candidates")
      .update({ status: data.status, reviewed_by: context.userId, updated_at: new Date().toISOString() })
      .eq("id", data.id);
    if (error) throw error;
    await writeAuditLog(context.userId, "update_source_candidate", "source_candidates", data.id, { status: data.status });
    return { ok: true };
  });

  .middleware([requireRole("admin")])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.from("feature_flags").select("*").order("key");
    if (error) throw error;
    return data ?? [];
  });

export const setFeatureFlag = createServerFn({ method: "POST" })
  .middleware([requireRole("admin")])
  .inputValidator((d) =>
    z.object({ key: z.string().min(1).max(60), enabled: z.boolean(), description: z.string().max(200).optional() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("feature_flags")
      .upsert(
        { key: data.key, enabled: data.enabled, description: data.description ?? null, updated_by: context.userId, updated_at: new Date().toISOString() },
        { onConflict: "key" },
      );
    if (error) throw error;
    await writeAuditLog(context.userId, "set_feature_flag", "feature_flags", data.key, { enabled: data.enabled });
    return { ok: true };
  });
