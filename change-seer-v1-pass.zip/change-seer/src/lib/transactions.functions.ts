import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const KINDS = ["income", "expense", "investment", "withdrawal", "refund", "fee"] as const;

export const listTransactions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ projectId: z.string().uuid().optional() }).parse(d ?? {}))
  .handler(async ({ data, context }) => {
    let query = context.supabase
      .from("transactions")
      .select("*")
      .eq("user_id", context.userId)
      .order("occurred_at", { ascending: false });
    if (data.projectId) query = query.eq("project_id", data.projectId);
    const { data: rows, error } = await query;
    if (error) throw error;
    return rows ?? [];
  });

export const createTransaction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      projectId: z.string().uuid().optional().nullable(),
      kind: z.enum(KINDS),
      amountCents: z.number().int().positive(),
      currency: z.string().length(3).default("USD"),
      category: z.string().max(60).optional().nullable(),
      description: z.string().max(300).optional().nullable(),
      note: z.string().max(1000).optional().nullable(),
      occurredAt: z.string().datetime().optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("transactions")
      .insert({
        user_id: context.userId,
        project_id: data.projectId ?? null,
        kind: data.kind,
        amount_cents: data.amountCents,
        currency: data.currency,
        category: data.category ?? null,
        description: data.description ?? null,
        note: data.note ?? null,
        occurred_at: data.occurredAt ?? new Date().toISOString(),
      })
      .select()
      .single();
    if (error) throw error;

    if (data.kind === "income") {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin
        .from("user_badges")
        .insert({ user_id: context.userId, badge_id: "first-sale" })
        .select()
        .maybeSingle();
    }

    await context.supabase.from("product_events").insert({
      user_id: context.userId,
      event_name: "transaction_added",
      subject_type: "transaction",
      subject_id: row.id,
      meta: { kind: data.kind, projectId: data.projectId ?? null } as never,
    });

    return row;
  });

export const deleteTransaction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("transactions")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw error;
    return { ok: true };
  });

/**
 * Cash-flow summary — pure aggregation, computed the same way whether it's
 * shown for a single project or across all of a user's projects. Revenue
 * and profit are never the same number: profit subtracts expenses/fees
 * and adds refunds back; invested capital is tracked separately from
 * profit so ROI can't be silently inflated by counting your own deposits
 * as earnings.
 */
export const getCashFlowSummary = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: rows, error } = await context.supabase
      .from("transactions")
      .select("kind, amount_cents, project_id, occurred_at");
    if (error) throw error;

    const totals = { income: 0, expense: 0, investment: 0, withdrawal: 0, refund: 0, fee: 0 };
    for (const r of rows ?? []) {
      totals[r.kind as keyof typeof totals] += r.amount_cents;
    }

    const totalRevenueCents = totals.income;
    const totalExpensesCents = totals.expense + totals.fee - totals.refund;
    const totalInvestedCents = totals.investment;
    const netProfitCents = totalRevenueCents - totalExpensesCents;
    const roi = totalInvestedCents > 0 ? netProfitCents / totalInvestedCents : null;

    const byProject = new Map<string, { revenue: number; expenses: number; invested: number }>();
    for (const r of rows ?? []) {
      if (!r.project_id) continue;
      const entry = byProject.get(r.project_id) ?? { revenue: 0, expenses: 0, invested: 0 };
      if (r.kind === "income") entry.revenue += r.amount_cents;
      if (r.kind === "expense" || r.kind === "fee") entry.expenses += r.amount_cents;
      if (r.kind === "refund") entry.expenses -= r.amount_cents;
      if (r.kind === "investment") entry.invested += r.amount_cents;
      byProject.set(r.project_id, entry);
    }

    return {
      totalRevenueCents,
      totalExpensesCents,
      totalInvestedCents,
      netProfitCents,
      roi,
      byProject: Object.fromEntries(byProject),
      transactionCount: (rows ?? []).length,
    };
  });
