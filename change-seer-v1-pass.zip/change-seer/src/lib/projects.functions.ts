import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const PROJECT_STATUSES = ["exploring", "building", "launched", "paused", "shelved"] as const;

export const listMyProjects = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("projects")
      .select("*, transactions(amount_cents, kind)")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  });

export const createProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      name: z.string().min(1).max(120),
      opportunityId: z.string().max(200).optional().nullable(),
      description: z.string().max(2000).optional().nullable(),
      target: z.string().max(300).optional().nullable(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("projects")
      .insert({
        user_id: context.userId,
        name: data.name,
        opportunity_id: data.opportunityId ?? null,
        description: data.description ?? null,
        target: data.target ?? null,
      })
      .select()
      .single();
    if (error) throw error;

    // First Build badge — idempotent, ignored on conflict.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("user_badges")
      .insert({ user_id: context.userId, badge_id: "first-build" })
      .select()
      .maybeSingle();

    await context.supabase.from("product_events").insert({
      user_id: context.userId,
      event_name: "project_created",
      subject_type: "project",
      subject_id: row.id,
      meta: { fromOpportunityId: data.opportunityId ?? null } as never,
    });

    return row;
  });

export const updateProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      id: z.string().uuid(),
      name: z.string().min(1).max(120).optional(),
      description: z.string().max(2000).optional().nullable(),
      status: z.enum(PROJECT_STATUSES).optional(),
      target: z.string().max(300).optional().nullable(),
      visibility: z.enum(["public", "private"]).optional(),
      timeInvestedHours: z.number().min(0).max(100000).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { id, timeInvestedHours, ...rest } = data;
    const patch: Record<string, unknown> = { ...rest, updated_at: new Date().toISOString() };
    if (timeInvestedHours !== undefined) patch.time_invested_hours = timeInvestedHours;

    const { error } = await context.supabase
      .from("projects")
      .update(patch)
      .eq("id", id)
      .eq("user_id", context.userId);
    if (error) throw error;
    return { ok: true };
  });

export const deleteProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("projects")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw error;
    return { ok: true };
  });

export const listProjectUpdates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ projectId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("project_updates")
      .select("*")
      .eq("project_id", data.projectId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return rows ?? [];
  });

export const addProjectUpdate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ projectId: z.string().uuid(), body: z.string().min(1).max(2000) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("project_updates")
      .insert({ project_id: data.projectId, user_id: context.userId, body: data.body });
    if (error) throw error;
    return { ok: true };
  });
