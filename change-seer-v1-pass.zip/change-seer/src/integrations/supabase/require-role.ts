import { createMiddleware } from "@tanstack/react-start";
import { requireSupabaseAuth } from "./auth-middleware";
import type { Database } from "./types";

type AppRole = Database["public"]["Enums"]["app_role"];

/**
 * Authorization is enforced here (server-side) via `has_at_least`, a
 * SECURITY DEFINER function that reads user_roles directly — never by
 * trusting a role claimed by the client. Compose with requireSupabaseAuth
 * so every admin server function gets both an authenticated user AND a
 * verified minimum role before its handler runs.
 *
 * Usage: .middleware([requireRole("admin")])
 */
export function requireRole(minRole: AppRole) {
  return createMiddleware({ type: "function" })
    .middleware([requireSupabaseAuth])
    .server(async ({ next, context }) => {
      const { data, error } = await context.supabase.rpc("has_at_least", {
        _user_id: context.userId,
        _min: minRole,
      });
      if (error || !data) {
        throw new Error(`Forbidden: requires ${minRole} role or higher`);
      }
      return next({ context });
    });
}
