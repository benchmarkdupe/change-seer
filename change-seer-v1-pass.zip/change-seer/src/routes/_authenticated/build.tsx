import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Hammer, Loader2, Plus, Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import {
  listMyProjects,
  createProject,
  updateProject,
  deleteProject,
  listProjectUpdates,
  addProjectUpdate,
} from "@/lib/projects.functions";

const STATUSES = ["exploring", "building", "launched", "paused", "shelved"] as const;
type Status = (typeof STATUSES)[number];

const STATUS_LABEL: Record<Status, string> = {
  exploring: "Exploring",
  building: "Building",
  launched: "Launched",
  paused: "Paused",
  shelved: "Shelved",
};

type ProjectRow = {
  id: string;
  name: string;
  description: string | null;
  status: Status;
  target: string | null;
  time_invested_hours: number;
  opportunity_id: string | null;
  visibility: "public" | "private";
  transactions?: { amount_cents: number; kind: string }[];
};

function centsToDisplay(cents: number) {
  return (cents / 100).toLocaleString(undefined, { style: "currency", currency: "USD" });
}

export const Route = createFileRoute("/_authenticated/build")({
  validateSearch: (s: Record<string, unknown>) => ({
    opportunityId: typeof s.opportunityId === "string" ? s.opportunityId : undefined,
    opportunityTitle: typeof s.opportunityTitle === "string" ? s.opportunityTitle : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Build — OpportunityOS" },
      { name: "description", content: "Turn opportunities into projects you're actually working on, and track what happens." },
    ],
  }),
  loader: ({ context }) =>
    context.queryClient.ensureQueryData({ queryKey: ["my-projects"], queryFn: () => listMyProjects() }),
  component: BuildPage,
});

function BuildPage() {
  const qc = useQueryClient();
  const fetchProjects = useServerFn(listMyProjects);
  const { data } = useSuspenseQuery({ queryKey: ["my-projects"], queryFn: () => fetchProjects() });
  const projects = (data ?? []) as unknown as ProjectRow[];
  const search = Route.useSearch();

  const [showNew, setShowNew] = useState(!!search.opportunityId);

  const refresh = () => qc.invalidateQueries({ queryKey: ["my-projects"] });

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl px-4 pb-8 pt-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Hammer className="h-5 w-5 text-primary" />
              <h1 className="font-display text-2xl font-semibold tracking-tight">Build</h1>
            </div>
            <p className="mt-1 text-[13px] text-muted-foreground">
              Real projects, in your own words — no template numbers.
            </p>
          </div>
          <button
            onClick={() => setShowNew((v) => !v)}
            className="inline-flex h-9 items-center gap-1.5 rounded-full bg-primary px-3 text-[13px] font-medium text-primary-foreground"
          >
            <Plus className="h-4 w-4" /> New
          </button>
        </div>

        {showNew && (
          <NewProjectForm
            initialName={search.opportunityTitle}
            opportunityId={search.opportunityId}
            onCreated={() => { setShowNew(false); refresh(); }}
          />
        )}

        {projects.length === 0 && !showNew ? (
          <div className="mt-8 rounded-2xl border border-dashed border-border p-8 text-center">
            <Hammer className="mx-auto h-6 w-6 text-muted-foreground" />
            <p className="mt-3 text-[13px] text-muted-foreground">
              Nothing started yet. Tap "New" or save an opportunity from Discover and start a project from it.
            </p>
          </div>
        ) : (
          <div className="mt-5 space-y-3">
            {projects.map((p) => (
              <ProjectCard key={p.id} project={p} onChanged={refresh} />
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}

function NewProjectForm({
  onCreated, initialName, opportunityId,
}: { onCreated: () => void; initialName?: string; opportunityId?: string }) {
  const create = useServerFn(createProject);
  const [name, setName] = useState(initialName ?? "");
  const [description, setDescription] = useState("");
  const [target, setTarget] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async () => {
    if (!name.trim()) return;
    setBusy(true);
    setErr(null);
    try {
      await create({
        data: { name, description: description || null, target: target || null, opportunityId: opportunityId ?? null },
      });
      onCreated();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not create project");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-4 space-y-2.5 rounded-2xl border border-border bg-surface p-4">
      <input
        value={name} onChange={(e) => setName(e.target.value)} placeholder="Project name"
        className="h-10 w-full rounded-xl border border-border bg-background px-3 text-[14px] focus:border-primary focus:outline-none"
      />
      <textarea
        value={description} onChange={(e) => setDescription(e.target.value)} rows={2}
        placeholder="What is this, briefly?"
        className="w-full rounded-xl border border-border bg-background p-3 text-[13px] focus:border-primary focus:outline-none"
      />
      <input
        value={target} onChange={(e) => setTarget(e.target.value)} placeholder="Target (optional) — e.g. $500/mo by March"
        className="h-10 w-full rounded-xl border border-border bg-background px-3 text-[13px] focus:border-primary focus:outline-none"
      />
      {err && <p className="text-[12px] text-tier-low">{err}</p>}
      <button
        onClick={submit} disabled={busy || !name.trim()}
        className="flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-primary text-[13px] font-medium text-primary-foreground disabled:opacity-50"
      >
        {busy && <Loader2 className="h-4 w-4 animate-spin" />}
        Start project
      </button>
    </div>
  );
}

function ProjectCard({ project, onChanged }: { project: ProjectRow; onChanged: () => void }) {
  const update = useServerFn(updateProject);
  const remove = useServerFn(deleteProject);
  const fetchUpdates = useServerFn(listProjectUpdates);
  const addUpdate = useServerFn(addProjectUpdate);

  const [expanded, setExpanded] = useState(false);
  const [updates, setUpdates] = useState<{ id: string; body: string; created_at: string }[] | null>(null);
  const [newUpdate, setNewUpdate] = useState("");
  const [busy, setBusy] = useState(false);

  const revenue = (project.transactions ?? [])
    .filter((t) => t.kind === "income")
    .reduce((s, t) => s + t.amount_cents, 0);
  const expenses = (project.transactions ?? [])
    .filter((t) => t.kind === "expense" || t.kind === "fee")
    .reduce((s, t) => s + t.amount_cents, 0);

  const toggle = async () => {
    setExpanded((v) => !v);
    if (!expanded && updates === null) {
      const rows = await fetchUpdates({ data: { projectId: project.id } });
      setUpdates(rows as typeof updates);
    }
  };

  const changeStatus = async (status: Status) => {
    await update({ data: { id: project.id, status } });
    onChanged();
  };

  const del = async () => {
    if (!confirm(`Delete "${project.name}"? This can't be undone.`)) return;
    await remove({ data: { id: project.id } });
    onChanged();
  };

  const postUpdate = async () => {
    if (!newUpdate.trim()) return;
    setBusy(true);
    try {
      await addUpdate({ data: { projectId: project.id, body: newUpdate } });
      const rows = await fetchUpdates({ data: { projectId: project.id } });
      setUpdates(rows as typeof updates);
      setNewUpdate("");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="truncate font-display text-[15px] font-semibold">{project.name}</h3>
          {project.description && (
            <p className="mt-0.5 text-[13px] leading-relaxed text-foreground/80">{project.description}</p>
          )}
        </div>
        <button onClick={del} className="shrink-0 rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-tier-low" aria-label="Delete project">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <select
          value={project.status}
          onChange={(e) => changeStatus(e.target.value as Status)}
          className="rounded-full border border-border bg-surface px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-foreground"
        >
          {STATUSES.map((s) => (
            <option key={s} value={s}>{STATUS_LABEL[s]}</option>
          ))}
        </select>
        {project.target && (
          <span className="text-[11px] text-muted-foreground">Target: {project.target}</span>
        )}
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border-soft pt-3 text-center">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Revenue</div>
          <div className="mt-0.5 font-mono text-[13px]">{centsToDisplay(revenue)}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Expenses</div>
          <div className="mt-0.5 font-mono text-[13px]">{centsToDisplay(expenses)}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Net</div>
          <div className={`mt-0.5 font-mono text-[13px] ${revenue - expenses >= 0 ? "text-tier-high" : "text-tier-low"}`}>
            {centsToDisplay(revenue - expenses)}
          </div>
        </div>
      </div>

      <button onClick={toggle} className="mt-3 flex w-full items-center justify-center gap-1 rounded-lg py-1.5 text-[11px] font-medium text-muted-foreground hover:bg-muted">
        {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        Progress log
      </button>

      {expanded && (
        <div className="mt-2 space-y-2">
          <div className="flex gap-2">
            <input
              value={newUpdate} onChange={(e) => setNewUpdate(e.target.value)}
              placeholder="What happened?"
              className="h-9 flex-1 rounded-lg border border-border bg-background px-2.5 text-[12px] focus:border-primary focus:outline-none"
            />
            <button onClick={postUpdate} disabled={busy || !newUpdate.trim()} className="rounded-lg bg-primary px-3 text-[12px] font-medium text-primary-foreground disabled:opacity-50">
              Log
            </button>
          </div>
          {(updates ?? []).length === 0 ? (
            <p className="text-[11px] text-muted-foreground">No entries yet.</p>
          ) : (
            <ul className="space-y-1.5">
              {(updates ?? []).map((u) => (
                <li key={u.id} className="rounded-lg bg-surface-sunken/60 p-2 text-[12px]">
                  <p className="text-foreground/90">{u.body}</p>
                  <p className="mt-0.5 font-mono text-[10px] text-muted-foreground">
                    {new Date(u.created_at).toLocaleString()}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
