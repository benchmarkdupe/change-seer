import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { ArrowLeft, ShieldAlert, Loader2 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  listUsers,
  grantRole,
  revokeRole,
  listAuditLog,
  listFeatureFlags,
  setFeatureFlag,
  grantBadge,
  revokeBadge,
  getSystemStats,
  listSourceCandidates,
  updateSourceCandidateStatus,
} from "@/lib/admin.functions";

const ASSIGNABLE_ROLES = ["early_access", "builder", "moderator", "admin", "developer"] as const;
const GRANTABLE_BADGES = ["verified-builder", "verified-outcome", "contributor", "moderator"] as const;
const CANDIDATE_STATUSES = [
  "discovered", "reviewed", "approved", "implementation_proposed", "implemented", "monitored", "rejected",
] as const;

export const Route = createFileRoute("/_authenticated/admin-console")({
  head: () => ({
    meta: [{ title: "Admin console — OpportunityOS" }, { name: "robots", content: "noindex" }],
  }),
  component: AdminConsolePage,
});

function AdminConsolePage() {
  const fetchUsers = useServerFn(listUsers);
  const usersQuery = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => fetchUsers({ data: {} }),
    retry: false,
  });

  if (usersQuery.isLoading) {
    return (
      <AppShell>
        <div className="grid h-[60vh] place-items-center">
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        </div>
      </AppShell>
    );
  }

  if (usersQuery.isError) {
    return (
      <AppShell>
        <div className="mx-auto max-w-md px-6 py-20 text-center">
          <ShieldAlert className="mx-auto h-8 w-8 text-tier-low" />
          <h1 className="mt-4 font-display text-xl font-semibold">Admins only</h1>
          <p className="mt-2 text-[13px] text-muted-foreground">
            This console is restricted to platform admins and the owner account.
          </p>
          <Link to="/" className="mt-6 inline-flex rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
            Back to Discover
          </Link>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl px-4 pb-10 pt-6">
        <Link to="/" className="inline-flex items-center gap-1.5 text-[13px] text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> Back
        </Link>
        <h1 className="mt-3 font-display text-2xl font-semibold tracking-tight">Admin console</h1>
        <p className="mt-1 text-[13px] text-muted-foreground">
          Every action here is written to the audit log. Owner role can't be changed from this screen.
        </p>

        <Tabs defaultValue="users" className="mt-5">
          <TabsList>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
            <TabsTrigger value="sources">Sources</TabsTrigger>
            <TabsTrigger value="audit">Audit log</TabsTrigger>
            <TabsTrigger value="flags">Feature flags</TabsTrigger>
          </TabsList>
          <TabsContent value="users" className="mt-4">
            <UsersTab users={usersQuery.data ?? []} />
          </TabsContent>
          <TabsContent value="system" className="mt-4">
            <SystemTab />
          </TabsContent>
          <TabsContent value="sources" className="mt-4">
            <SourcesTab />
          </TabsContent>
          <TabsContent value="audit" className="mt-4">
            <AuditTab />
          </TabsContent>
          <TabsContent value="flags" className="mt-4">
            <FlagsTab />
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}

type UserRow = {
  id: string;
  username: string | null;
  display_name: string | null;
  created_at: string;
  user_roles: { role: string }[];
  user_badges: { badge_id: string }[];
};

function UsersTab({ users }: { users: UserRow[] }) {
  const qc = useQueryClient();
  const grant = useServerFn(grantRole);
  const revoke = useServerFn(revokeRole);
  const grantBadgeFn = useServerFn(grantBadge);
  const revokeBadgeFn = useServerFn(revokeBadge);
  const [pending, setPending] = useState<string | null>(null);

  const toggle = async (userId: string, role: string, has: boolean) => {
    setPending(`${userId}:${role}`);
    try {
      if (has) await revoke({ data: { userId, role: role as (typeof ASSIGNABLE_ROLES)[number] } });
      else await grant({ data: { userId, role: role as (typeof ASSIGNABLE_ROLES)[number] } });
      await qc.invalidateQueries({ queryKey: ["admin-users"] });
    } finally {
      setPending(null);
    }
  };

  const toggleBadge = async (userId: string, badgeId: string, has: boolean) => {
    setPending(`badge:${userId}:${badgeId}`);
    try {
      if (has) await revokeBadgeFn({ data: { userId, badgeId } });
      else await grantBadgeFn({ data: { userId, badgeId } });
      await qc.invalidateQueries({ queryKey: ["admin-users"] });
    } finally {
      setPending(null);
    }
  };

  return (
    <div className="space-y-2">
      {users.map((u) => {
        const roles = new Set(u.user_roles.map((r) => r.role));
        const badges = new Set(u.user_badges.map((b) => b.badge_id));
        const isOwner = roles.has("owner");
        return (
          <div key={u.id} className="rounded-xl border border-border-soft bg-surface p-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[13px] font-medium">{u.display_name ?? u.username ?? "Unnamed"}</span>
                {u.username && <span className="ml-1.5 text-[11px] text-muted-foreground">@{u.username}</span>}
              </div>
              <span className="font-mono text-[10px] text-muted-foreground">
                {new Date(u.created_at).toLocaleDateString()}
              </span>
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {isOwner && (
                <span className="rounded-full bg-tier-high/15 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-tier-high">
                  Owner (protected)
                </span>
              )}
              {ASSIGNABLE_ROLES.map((role) => {
                const has = roles.has(role);
                const key = `${u.id}:${role}`;
                return (
                  <button
                    key={role}
                    disabled={pending === key || isOwner}
                    onClick={() => toggle(u.id, role, has)}
                    className={`rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider disabled:opacity-50 ${
                      has ? "border-primary/50 bg-primary-soft text-primary" : "border-border text-muted-foreground"
                    }`}
                  >
                    {role.replace("_", " ")}
                  </button>
                );
              })}
            </div>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {GRANTABLE_BADGES.map((badgeId) => {
                const has = badges.has(badgeId);
                const key = `badge:${u.id}:${badgeId}`;
                return (
                  <button
                    key={badgeId}
                    disabled={pending === key}
                    onClick={() => toggleBadge(u.id, badgeId, has)}
                    className={`rounded-full border px-2 py-0.5 text-[10px] disabled:opacity-50 ${
                      has ? "border-tier-high/40 bg-tier-high/10 text-tier-high" : "border-dashed border-border text-muted-foreground"
                    }`}
                  >
                    {badgeId.replace("-", " ")}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function SystemTab() {
  const fetchStats = useServerFn(getSystemStats);
  const { data, isLoading } = useQuery({ queryKey: ["admin-system"], queryFn: () => fetchStats() });

  if (isLoading || !data) {
    return <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />;
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2">
        <Stat label="Users" value={data.totalUsers} />
        <Stat label="Projects" value={data.totalProjects} />
        <Stat label="Transactions" value={data.totalTransactions} />
        <Stat label="Saved opportunities" value={data.totalSavedOpportunities} />
        <Stat label="Events (24h)" value={data.eventsLast24h} />
      </div>
      <div>
        <h3 className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Source health</h3>
        <div className="mt-2 space-y-2">
          {data.sources.map((s) => (
            <div key={s.scout_id} className="flex items-center justify-between rounded-xl border border-border-soft bg-surface p-3 text-[12px]">
              <div>
                <span className="font-medium">{s.scout_id}</span>
                <span className="ml-2 text-muted-foreground">
                  last success {s.last_success_at ? new Date(s.last_success_at).toLocaleString() : "never"}
                </span>
              </div>
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider ${
                  s.status === "healthy" ? "bg-tier-high/15 text-tier-high" : s.status === "down" ? "bg-tier-low/15 text-tier-low" : "bg-muted text-muted-foreground"
                }`}
              >
                {s.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-mono text-[18px] font-semibold">{value}</div>
    </div>
  );
}

function SourcesTab() {
  const qc = useQueryClient();
  const fetchCandidates = useServerFn(listSourceCandidates);
  const setStatus = useServerFn(updateSourceCandidateStatus);
  const { data } = useQuery({ queryKey: ["admin-sources"], queryFn: () => fetchCandidates() });

  const changeStatus = async (id: string, status: (typeof CANDIDATE_STATUSES)[number]) => {
    await setStatus({ data: { id, status } });
    await qc.invalidateQueries({ queryKey: ["admin-sources"] });
  };

  return (
    <div className="space-y-2">
      {(data ?? []).map((c) => (
        <div key={c.id} className="rounded-xl border border-border-soft bg-surface p-3">
          <div className="flex items-center justify-between">
            <span className="text-[13px] font-medium">{c.name}</span>
            <select
              value={c.status}
              onChange={(e) => changeStatus(c.id, e.target.value as (typeof CANDIDATE_STATUSES)[number])}
              className="rounded-full border border-border bg-background px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider"
            >
              {CANDIDATE_STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
            </select>
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground">{c.category} · {c.implementation_difficulty ?? "unknown"} difficulty</p>
          {c.rationale && <p className="mt-1 text-[12px] text-foreground/85">{c.rationale}</p>}
        </div>
      ))}
    </div>
  );
}

function AuditTab() {
  const fetchLog = useServerFn(listAuditLog);
  const { data } = useQuery({ queryKey: ["admin-audit"], queryFn: () => fetchLog() });

  return (
    <div className="space-y-2">
      {(data ?? []).length === 0 && <p className="text-[13px] text-muted-foreground">No actions logged yet.</p>}
      {(data ?? []).map((entry) => (
        <div key={entry.id} className="rounded-xl border border-border-soft bg-surface p-3 text-[12px]">
          <div className="flex items-center justify-between">
            <span className="font-medium">{entry.action}</span>
            <span className="font-mono text-[10px] text-muted-foreground">{new Date(entry.created_at).toLocaleString()}</span>
          </div>
          <div className="mt-1 text-muted-foreground">
            {entry.target_table} · {entry.target_id}
          </div>
        </div>
      ))}
    </div>
  );
}

function FlagsTab() {
  const qc = useQueryClient();
  const fetchFlags = useServerFn(listFeatureFlags);
  const set = useServerFn(setFeatureFlag);
  const { data } = useQuery({ queryKey: ["admin-flags"], queryFn: () => fetchFlags() });

  const toggle = async (key: string, enabled: boolean) => {
    await set({ data: { key, enabled: !enabled } });
    await qc.invalidateQueries({ queryKey: ["admin-flags"] });
  };

  return (
    <div className="space-y-2">
      {(data ?? []).length === 0 && <p className="text-[13px] text-muted-foreground">No feature flags defined yet.</p>}
      {(data ?? []).map((flag) => (
        <div key={flag.key} className="flex items-center justify-between rounded-xl border border-border-soft bg-surface p-3">
          <div>
            <div className="font-mono text-[12px]">{flag.key}</div>
            {flag.description && <div className="text-[11px] text-muted-foreground">{flag.description}</div>}
          </div>
          <button
            onClick={() => toggle(flag.key, flag.enabled)}
            className={`rounded-full px-3 py-1 text-[11px] font-medium ${flag.enabled ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
          >
            {flag.enabled ? "Enabled" : "Disabled"}
          </button>
        </div>
      ))}
    </div>
  );
}
