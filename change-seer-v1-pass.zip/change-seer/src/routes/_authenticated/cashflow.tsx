import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Wallet, Loader2, Plus, Trash2 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { listMyProjects } from "@/lib/projects.functions";
import {
  listTransactions,
  createTransaction,
  deleteTransaction,
  getCashFlowSummary,
} from "@/lib/transactions.functions";

const KINDS = ["income", "expense", "investment", "withdrawal", "refund", "fee"] as const;
type Kind = (typeof KINDS)[number];

const KIND_LABEL: Record<Kind, string> = {
  income: "Income",
  expense: "Expense",
  investment: "Investment (capital in)",
  withdrawal: "Withdrawal",
  refund: "Refund",
  fee: "Fee",
};

function money(cents: number) {
  return (cents / 100).toLocaleString(undefined, { style: "currency", currency: "USD" });
}

export const Route = createFileRoute("/_authenticated/cashflow")({
  head: () => ({
    meta: [
      { title: "Cash Flow — OpportunityOS" },
      { name: "description", content: "One honest view of every project you're running — what's growing, what's not." },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData({ queryKey: ["transactions"], queryFn: () => listTransactions({ data: {} }) }),
      context.queryClient.ensureQueryData({ queryKey: ["cashflow-summary"], queryFn: () => getCashFlowSummary() }),
    ]),
  component: CashFlowPage,
});

function CashFlowPage() {
  const qc = useQueryClient();
  const fetchTx = useServerFn(listTransactions);
  const fetchSummary = useServerFn(getCashFlowSummary);
  const fetchProjects = useServerFn(listMyProjects);
  const remove = useServerFn(deleteTransaction);

  const { data: transactions } = useSuspenseQuery({
    queryKey: ["transactions"],
    queryFn: () => fetchTx({ data: {} }),
  });
  const { data: summary } = useSuspenseQuery({
    queryKey: ["cashflow-summary"],
    queryFn: () => fetchSummary(),
  });
  const { data: projects } = useQuery({ queryKey: ["my-projects"], queryFn: () => fetchProjects() });

  const [showNew, setShowNew] = useState(false);

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["transactions"] });
    qc.invalidateQueries({ queryKey: ["cashflow-summary"] });
  };

  const del = async (id: string) => {
    await remove({ data: { id } });
    refresh();
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl px-4 pb-8 pt-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Wallet className="h-5 w-5 text-primary" />
              <h1 className="font-display text-2xl font-semibold tracking-tight">Cash Flow</h1>
            </div>
            <p className="mt-1 text-[13px] text-muted-foreground">Manual tracking. Real numbers, not projections.</p>
          </div>
          <button onClick={() => setShowNew((v) => !v)} className="inline-flex h-9 items-center gap-1.5 rounded-full bg-primary px-3 text-[13px] font-medium text-primary-foreground">
            <Plus className="h-4 w-4" /> Add
          </button>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-2">
          <SummaryTile label="Revenue" value={money(summary.totalRevenueCents)} />
          <SummaryTile label="Expenses" value={money(summary.totalExpensesCents)} />
          <SummaryTile label="Invested" value={money(summary.totalInvestedCents)} />
          <SummaryTile
            label="Net profit"
            value={money(summary.netProfitCents)}
            tone={summary.netProfitCents >= 0 ? "high" : "low"}
          />
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
          Net profit = revenue − expenses/fees + refunds. Invested capital is tracked separately and never counted as profit.
          {summary.roi !== null && (
            <> ROI on invested capital: <span className="font-mono text-foreground">{(summary.roi * 100).toFixed(1)}%</span>.</>
          )}
        </p>

        {showNew && (
          <NewTransactionForm
            projects={(projects ?? []) as { id: string; name: string }[]}
            onCreated={() => { setShowNew(false); refresh(); }}
          />
        )}

        <h2 className="mt-6 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          {transactions.length} transaction{transactions.length === 1 ? "" : "s"}
        </h2>

        {transactions.length === 0 ? (
          <div className="mt-3 rounded-2xl border border-dashed border-border p-8 text-center">
            <p className="text-[13px] text-muted-foreground">No transactions yet. Log your first one above.</p>
          </div>
        ) : (
          <div className="mt-3 space-y-2">
            {transactions.map((t) => (
              <div key={t.id} className="flex items-center justify-between gap-3 rounded-xl border border-border-soft bg-surface p-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 text-[12px]">
                    <span className="rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                      {KIND_LABEL[t.kind as Kind]}
                    </span>
                    <span className="text-muted-foreground">{new Date(t.occurred_at).toLocaleDateString()}</span>
                  </div>
                  {t.description && <p className="mt-1 truncate text-[13px] text-foreground/90">{t.description}</p>}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span className={`font-mono text-[13px] ${t.kind === "income" ? "text-tier-high" : "text-foreground"}`}>
                    {money(t.amount_cents)}
                  </span>
                  <button onClick={() => del(t.id)} className="rounded-lg p-1 text-muted-foreground hover:bg-muted hover:text-tier-low" aria-label="Delete">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}

function SummaryTile({ label, value, tone }: { label: string; value: string; tone?: "high" | "low" }) {
  const toneClass = tone === "high" ? "text-tier-high" : tone === "low" ? "text-tier-low" : "text-foreground";
  return (
    <div className="rounded-2xl border border-border bg-card p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 font-mono text-[16px] font-semibold ${toneClass}`}>{value}</div>
    </div>
  );
}

function NewTransactionForm({ projects, onCreated }: { projects: { id: string; name: string }[]; onCreated: () => void }) {
  const create = useServerFn(createTransaction);
  const [kind, setKind] = useState<Kind>("income");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [projectId, setProjectId] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const submit = async () => {
    const dollars = Number(amount);
    if (!dollars || dollars <= 0) {
      setErr("Enter an amount greater than 0");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      await create({
        data: {
          kind,
          amountCents: Math.round(dollars * 100),
          description: description || null,
          projectId: projectId || null,
        },
      });
      setAmount("");
      setDescription("");
      onCreated();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not save transaction");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-4 space-y-2.5 rounded-2xl border border-border bg-surface p-4">
      <div className="grid grid-cols-2 gap-2">
        <select value={kind} onChange={(e) => setKind(e.target.value as Kind)} className="h-10 rounded-xl border border-border bg-background px-2.5 text-[13px]">
          {KINDS.map((k) => <option key={k} value={k}>{KIND_LABEL[k]}</option>)}
        </select>
        <input
          value={amount} onChange={(e) => setAmount(e.target.value)} type="number" min="0" step="0.01" placeholder="Amount ($)"
          className="h-10 rounded-xl border border-border bg-background px-3 text-[13px] focus:border-primary focus:outline-none"
        />
      </div>
      {projects.length > 0 && (
        <select value={projectId} onChange={(e) => setProjectId(e.target.value)} className="h-10 w-full rounded-xl border border-border bg-background px-2.5 text-[13px]">
          <option value="">No project (unassigned)</option>
          {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      )}
      <input
        value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Note (optional)"
        className="h-10 w-full rounded-xl border border-border bg-background px-3 text-[13px] focus:border-primary focus:outline-none"
      />
      {err && <p className="text-[12px] text-tier-low">{err}</p>}
      <button onClick={submit} disabled={busy} className="flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-primary text-[13px] font-medium text-primary-foreground disabled:opacity-50">
        {busy && <Loader2 className="h-4 w-4 animate-spin" />}
        Save transaction
      </button>
    </div>
  );
}
