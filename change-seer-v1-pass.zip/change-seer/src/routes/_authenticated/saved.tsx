import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Bookmark } from "lucide-react";
import { listSaved } from "@/lib/saved.functions";
import { getLiveOpportunities } from "@/lib/opportunities.functions";
import { SAMPLE_OPPORTUNITIES, SAMPLE_DATA_STATE } from "@/data/sample/opportunities";
import { OpportunityCard } from "@/components/opportunity/OpportunityCard";
import type { DataState } from "@/domain/dataState";

export const Route = createFileRoute("/_authenticated/saved")({
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData({ queryKey: ["saved"], queryFn: () => listSaved() }),
      context.queryClient.ensureQueryData({ queryKey: ["live-opps"], queryFn: () => getLiveOpportunities() }),
    ]),
  component: SavedPage,
});

function SavedPage() {
  const fetchSaved = useServerFn(listSaved);
  const fetchLive = useServerFn(getLiveOpportunities);
  const { data: saved } = useSuspenseQuery({ queryKey: ["saved"], queryFn: () => fetchSaved() });
  const { data: live } = useSuspenseQuery({ queryKey: ["live-opps"], queryFn: () => fetchLive() });

  // A saved opportunity can come from either the sample set or the live
  // scout feed — checking both is what makes "Saved" actually reflect
  // what a signed-in user tapped, regardless of its data state.
  const pool = [
    ...SAMPLE_OPPORTUNITIES.map((o) => ({ opp: o, state: SAMPLE_DATA_STATE })),
    ...live.opportunities.map((o) => ({ opp: o, state: "live" as DataState })),
  ];
  const opps = saved
    .map((s) => pool.find((p) => p.opp.id === s.opportunity_id))
    .filter((p): p is (typeof pool)[number] => !!p);

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="sticky top-0 z-20 border-b border-border bg-background/85 px-4 py-3 backdrop-blur">
        <Link to="/" className="inline-flex items-center gap-1.5 text-[13px] text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> Back
        </Link>
      </header>
      <div className="px-4 pt-5">
        <h1 className="font-display text-2xl font-semibold tracking-tight">Saved</h1>
        <p className="mt-1 text-[13px] text-muted-foreground">
          Opportunities you flagged. When one crosses into High Signal, you'll earn an Early Signal badge.
        </p>
        {opps.length === 0 ? (
          <div className="mt-10 rounded-2xl border border-dashed border-border p-8 text-center">
            <Bookmark className="mx-auto h-6 w-6 text-muted-foreground" />
            <p className="mt-3 text-[13px] text-muted-foreground">Nothing saved yet. Tap the bookmark on any card.</p>
          </div>
        ) : (
          <div className="mt-5 space-y-3">
            {opps.map(({ opp, state }) => (
              <OpportunityCard key={opp.id} opp={opp} dataState={state} isSaved />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
